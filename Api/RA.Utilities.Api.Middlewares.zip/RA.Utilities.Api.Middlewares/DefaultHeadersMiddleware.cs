using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using RA.Utilities.Api.Middlewares.Extensions;
using RA.Utilities.Api.Middlewares.Models;
using RA.Utilities.Api.Middlewares.Options;
using RA.Utilities.Api.Middlewares.Utilities;
using RA.Utilities.Core.Constants;

namespace RA.Utilities.Api.Middlewares;

/// <summary>
/// Middleware to enforce the presence of the X-Request-Id header in incoming requests.
/// If the X-Request-Id header is missing, it returns a 400 Bad Request response.
/// </summary>
public class DefaultHeadersMiddleware : IMiddleware
{
    private readonly DefaultHeadersOptions _options;

    /// <summary>
    /// Initializes a new instance of the <see cref="DefaultHeadersMiddleware"/> class.
    /// </summary>
    /// <param name="options">The options for the default headers middleware.</param>
    public DefaultHeadersMiddleware(IOptions<DefaultHeadersOptions> options)
    {
        _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
    }

    /// <inheritdoc/>
    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        if (PathUtilities.ShouldIgnorePath(context.Request.Path, _options.PathsToIgnore))
        {
            await next(context);
            return;
        }

        string xRequestId = context.Request.Headers.GetXRequestId();

        if (string.IsNullOrWhiteSpace(xRequestId))
        {
            var response = new BadRequestResponse
            {
                ResponseCode = BaseResponseCode.BadRequest,
                ResponseType = ResponseType.BadRequest,
                ResponseMessage = BaseResponseMessages.BadRequest,
                Result = [
                    new() {
                        PropertyName = HeaderParameters.XRequestId,
                        ErrorMessage = $"Header '{HeaderParameters.XRequestId}' is required.",
                        ErrorCode = "NotNullValidator",
                    }
                ]
            };

            context.Response.Headers.TryAdd(HeaderParameters.Location, context.Request.Path.ToString());
            context.Response.Headers.TryAdd(HeaderParameters.XRequestId, Guid.NewGuid().ToString());

            context.Response.StatusCode = StatusCodes.Status400BadRequest;
            context.Response.ContentType = "application/json; charset=utf-8";
            string payload = JsonSerializer.Serialize(response);
            await context.Response.WriteAsync(payload, context.RequestAborted);

            // Short-circuit the pipeline — do not call the next middleware
            return;
        }

        context.Response.Headers.TryAdd(HeaderParameters.XRequestId, xRequestId);
        await next(context);
    }
}
